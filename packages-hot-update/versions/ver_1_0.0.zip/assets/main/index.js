window.__require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var b = o.split("/");
        b = b[b.length - 1];
        if (!t[b]) {
          var a = "function" == typeof __require && __require;
          if (!u && a) return a(b, !0);
          if (i) return i(b, !0);
          throw new Error("Cannot find module '" + o + "'");
        }
        o = b;
      }
      var f = n[o] = {
        exports: {}
      };
      t[o][0].call(f.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, f, f.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof __require && __require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  AppConfig: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "830f3pOGP5Pw6sxwz+04ZAz", "AppConfig");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.AppConfig = void 0;
    var AppConfig = {
      EvnEnum: {
        dev: "dev",
        test: "test",
        publish: "publish"
      },
      EvnType: "publish",
      isNotUpdate: true,
      appName: "quanmin",
      platform: 1,
      appId: 90,
      version: "1.0.0",
      coreVersion: "1.0.0",
      wwsValue: "ws",
      loginConfigUrl: "https://servercfg.oss-cn-shenzhen.aliyuncs.com/loginserverconfig.json",
      openId: "",
      channel: 1,
      deviceId: "aa:bb:cc:dd",
      webServerUrl: "",
      loginServerIP: "",
      loginServerPort: "",
      bundleUrl: "",
      whitePlayerList: []
    };
    exports.AppConfig = AppConfig;
    if (!window["initAppConfig"]) {
      if (AppConfig.EvnType === AppConfig.EvnEnum.dev) {
        AppConfig.webServerUrl = "http://nng1.16888game.com";
        AppConfig.loginServerIP = "";
        AppConfig.loginServerPort = "";
        AppConfig.bundleUrl = "http://192.168.0.16";
      } else if (AppConfig.EvnType === AppConfig.EvnEnum.test) {
        AppConfig.webServerUrl = "";
        AppConfig.loginServerIP = "";
        AppConfig.loginServerPort = "";
        AppConfig.bundleUrl = "";
      }
      window["initAppConfig"] = true;
    }
    cc._RF.pop();
  }, {} ],
  AssetsScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "7b847j5zzpIDa3myONJV/7B", "AssetsScene");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var AppConfig_1 = require("../AppConfig");
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var AssetsScene = function(_super) {
      __extends(AssetsScene, _super);
      function AssetsScene() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.manifestUrl = null;
        _this._storagePath = "";
        _this._am = null;
        _this._updateListener = null;
        _this._updating = false;
        _this._canRetry = false;
        _this._progress = 0;
        _this._tips = null;
        _this._updatePanel = null;
        _this._updatePanelTxBg = null;
        _this._upPanelTx = null;
        _this._upPanelProgressBar = null;
        _this._upPanel_progressTx = null;
        return _this;
      }
      AssetsScene.prototype.getChildNodeByName = function(root, name) {
        if (!root) return null;
        if (root.name === name) return root;
        for (var index = 0; index < root.childrenCount; index++) {
          var element = root.children[index];
          var res = this.getChildNodeByName(element, name);
          if (null !== res) return res;
        }
        return null;
      };
      AssetsScene.prototype.start = function() {
        var bg = this.getChildNodeByName(this.node, "bg");
        this.scaleBackgroundBG(bg);
        this._tips = this.getChildNodeByName(this.node, "tips");
        this._tips.active = false;
        this._updatePanel = this.getChildNodeByName(this.node, "updatePanel");
        this._updatePanelTxBg = this.getChildNodeByName(this.node, "upPanel_txbg");
        this._upPanelTx = this.getChildNodeByName(this.node, "upPanel_tx");
        var progress = this.getChildNodeByName(this.node, "upPanel_Progressbar");
        this._upPanel_progressTx = this.getChildNodeByName(this.node, "upPanel_progressTx").getComponent(cc.Label);
        this._upPanelProgressBar = progress.getComponent(cc.ProgressBar);
        this._upPanelProgressBar.progress = 0;
        this.getLoginServerConfig();
      };
      AssetsScene.prototype.getLoginServerConfig = function() {
        var _this = this;
        var req = new XMLHttpRequest();
        req.open("GET", AppConfig_1.AppConfig.loginConfigUrl, true);
        req.onreadystatechange = function() {
          cc.log("req.readyState : ", req.readyState);
          cc.log("req.status : ", req.status);
          if (4 === req.readyState && req.status >= 200 && req.status < 400) {
            var json = JSON.parse(req.responseText);
            cc.log("req.responseText : ", req.responseText);
            var g_server = json[AppConfig_1.AppConfig.appName];
            if (g_server) {
              if (AppConfig_1.AppConfig.EvnType === AppConfig_1.AppConfig.EvnEnum.publish) {
                AppConfig_1.AppConfig.webServerUrl = g_server.webUrl;
                AppConfig_1.AppConfig.loginServerIP = g_server.loginIp;
                AppConfig_1.AppConfig.loginServerPort = g_server.loginPort;
                AppConfig_1.AppConfig.bundleUrl = g_server.bundleUrl;
                AppConfig_1.AppConfig.whitePlayerList = g_server.whitePlayerList;
              }
              if (AppConfig_1.AppConfig.isNotUpdate) if (g_server.whiteUpSwitch) {
                var aid = cc.sys.localStorage.getItem("userAid");
                if (aid && "string" === typeof aid) {
                  var isNotPlayer = false;
                  for (var index = 0; index < g_server.whitePlayerList.length; index++) {
                    var id = g_server.whitePlayerList[index];
                    if (id === Number(aid)) {
                      isNotPlayer = true;
                      break;
                    }
                  }
                  if (isNotPlayer) {
                    cc.log("\u6d4b\u8bd5\u4eba\u5458\u767d\u540d\u5355\u70ed\u66f4\u65b0");
                    _this.startHotUpdate();
                  } else if (jsb.fileUtils.isFileExist(jsb.fileUtils.getWritablePath() + "/remote-asset/version.manifest")) {
                    cc.log("\u672c\u5730\u6709\u70ed\u66f4\u65b0\u7248\u672c,\u53ef\u4ee5\u6e38\u620f!");
                    _this.jumpToLoginScene();
                  } else {
                    cc.log("\u91cd\u7f6e\u66f4\u65b0\u4e0e\u65b0\u7528\u6237\u53ef\u4ee5\u66f4\u65b0\u5230\u53d1\u5e03\u7248\u672c");
                    _this.startHotUpdate();
                  }
                } else {
                  cc.log("\u767d\u540d\u5355\u70ed\u66f4\u65b0");
                  _this.startHotUpdate();
                }
              } else {
                cc.log("\u6b63\u5e38\u70ed\u66f4\u65b0");
                _this.startHotUpdate();
              } else _this.jumpToLoginScene();
            } else _this.showTips("\u83b7\u53d6\u8fdc\u7a0b\u670d\u52a1\u5668\u914d\u7f6e\u4fe1\u606f\u5931\u8d25,\u8bf7\u91cd\u8bd5!", function() {
              _this.getLoginServerConfig();
            });
          }
        };
        req.send();
      };
      AssetsScene.prototype.startHotUpdate = function() {
        if (!cc.sys.isNative) {
          this.jumpToLoginScene();
          return;
        }
        this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-asset";
        cc.log("Storage path for remote asset : " + this._storagePath);
        this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
        this._am.setVerifyCallback(function(path, asset) {
          var compressed = asset.compressed;
          var expectedMD5 = asset.md5;
          var relativePath = asset.path;
          var size = asset.size;
          return compressed, true;
        });
        cc.sys.os === cc.sys.OS_ANDROID && this._am.setMaxConcurrentTask(2);
        if (this._am && !this._updating) {
          this._am.setEventCallback(this.updateCb.bind(this));
          this._updateListener = true;
          if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
            var url = this.manifestUrl.nativeUrl;
            this._am.loadLocalManifest(url);
          }
          this._am.update();
          this._updating = true;
        }
      };
      AssetsScene.prototype.versionCompareHandle = function(versionA, versionB) {
        cc.log("JS Custom Version Compare : version A is " + versionA + ", version B is " + versionB);
        var vA = versionA.split(".");
        var vB = versionB.split(".");
        for (var i = 0; i < vA.length; i++) {
          var a = parseInt(vA[i]);
          var b = parseInt(vB[i] || 0);
          if (a === b) continue;
          return a - b;
        }
        return vB.length > vA.length ? -1 : 0;
      };
      AssetsScene.prototype.updateCb = function(event) {
        var _this = this;
        var needRestart = false;
        var failed = false;
        var failedType = "";
        switch (event.getEventCode()) {
         case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
          cc.log("\u7f3a\u5c11\u672c\u5730\u70ed\u66f4\u65b0\u914d\u7f6e\u6587\u4ef6 Manifest");
          failed = true;
          failedType = "\u7f3a\u5c11\u672c\u5730\u70ed\u66f4\u65b0\u914d\u7f6e\u6587\u4ef6 Manifest";
          break;

         case jsb.EventAssetsManager.UPDATE_PROGRESSION:
          this._upPanelProgressBar.progress = event.getPercent();
          var downloadedMegabyte = event.getDownloadedBytes() / 1048576;
          var totalMegabyte = event.getTotalBytes() / 1048576;
          var progressTx = downloadedMegabyte.toFixed(2) + "MB / " + totalMegabyte.toFixed(2) + "MB";
          cc.log("\u66f4\u65b0 : ", progressTx);
          this._upPanel_progressTx.string = progressTx;
          break;

         case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
          cc.log("\u4e0b\u8f7d\u914d\u7f6e\u6587\u4ef6\u5931\u8d25");
          failedType = "\u4e0b\u8f7d\u914d\u7f6e\u6587\u4ef6\u5931\u8d25,\u70b9\u51fb\u786e\u5b9a\u91cd\u8bd5!";
          this._updating = false;
          this._canRetry = true;
          break;

         case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
          cc.log("\u89e3\u6790\u914d\u7f6e\u6587\u4ef6\u5931\u8d25");
          failed = true;
          failedType = "\u89e3\u6790\u914d\u7f6e\u6587\u4ef6\u5931\u8d25";
          break;

         case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
          cc.log("\u5f53\u524d\u4e3a\u6700\u65b0\u7248\u672c");
          this.jumpToLoginScene();
          break;

         case jsb.EventAssetsManager.UPDATE_FINISHED:
          cc.log("\u66f4\u65b0\u5b8c\u6210");
          needRestart = true;
          break;

         case jsb.EventAssetsManager.UPDATE_FAILED:
          cc.log("\u66f4\u65b0\u5931\u8d25 : ", event.getMessage());
          this._updating = false;
          this._canRetry = true;
          failedType = "\u66f4\u65b0\u5931\u8d25,\u70b9\u51fb\u786e\u5b9a\u91cd\u8bd5!";
          break;

         case jsb.EventAssetsManager.ERROR_UPDATING:
          cc.log("\u4e0b\u8f7d\u5f02\u5e38 : ", event.getAssetId() + ", " + event.getMessage());
          failedType = "\u4e0b\u8f7d\u5f02\u5e38";
          this._updating = false;
          this._canRetry = true;
          break;

         case jsb.EventAssetsManager.ERROR_DECOMPRESS:
          cc.log("\u89e3\u538b\u5931\u8d25");
          failedType = "\u89e3\u538b\u5931\u8d25";
          this._updating = false;
          this._canRetry = true;
        }
        if (failed) {
          this._am.setEventCallback(null);
          this._updateListener = null;
          this._updating = false;
          this.showTips(failedType);
        }
        if (needRestart) {
          this._am.setEventCallback(null);
          this._updateListener = null;
          var searchPaths = jsb.fileUtils.getSearchPaths();
          var newPaths = this._am.getLocalManifest().getSearchPaths();
          cc.log("----------------- >>> ", JSON.stringify(newPaths));
          cc.log("----------------- >>> ", this._updating);
          cc.log("----------------- >>> ", this._canRetry);
          cc.log("----------------- >>> ", failed);
          Array.prototype.unshift.apply(searchPaths, newPaths);
          cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(searchPaths));
          jsb.fileUtils.setSearchPaths(searchPaths);
          cc.audioEngine.stopAll();
          cc.log("\u91cd\u542f");
          cc.game.restart();
        }
        !this._updating && this._canRetry && this.showTips(failedType, function() {
          _this._canRetry = false;
          _this._am.downloadFailedAssets();
        });
      };
      AssetsScene.prototype.showTips = function(content, continueCall, cancelCall) {
        var _this = this;
        var tx = this.getChildNodeByName(this._tips, "content");
        tx.getComponent(cc.Label).string = content;
        var cancelBtn = this.getChildNodeByName(this._tips, "cancel");
        var continueBtn = this.getChildNodeByName(this._tips, "continue");
        if (cancelCall) {
          cancelBtn.active = false;
          continueBtn.x = 0;
        } else {
          cancelBtn.active = true;
          cancelBtn.x = -100;
          continueBtn.x = 100;
        }
        continueCall && (continueBtn.active = false);
        continueBtn.on("click", function() {
          _this._tips.active = false;
          continueCall();
        });
        cancelBtn.on("click", function() {
          _this._tips.active = false;
          cancelCall();
        });
        this._tips.active = true;
      };
      AssetsScene.prototype.jumpToLoginScene = function() {
        cc.director.loadScene("LoginScene", function(err, scene) {
          var container = scene.children[0];
          var script = container.addComponent("LoginScene");
          script.setSceneType("login");
        });
      };
      AssetsScene.prototype.onDestroy = function() {
        if (this._updateListener) {
          this._am.setEventCallback(null);
          this._updateListener = null;
        }
      };
      AssetsScene.prototype.scaleBackgroundBG = function(node) {
        var showAll = Math.min(cc.view.getCanvasSize().width / node.width, cc.view.getCanvasSize().height / node.height);
        var realWidth = node.width * showAll;
        var realHeight = node.height * showAll;
        node.scale = Math.max(cc.view.getCanvasSize().width / realWidth, cc.view.getCanvasSize().height / realHeight);
      };
      __decorate([ property(cc.Asset) ], AssetsScene.prototype, "manifestUrl", void 0);
      AssetsScene = __decorate([ ccclass ], AssetsScene);
      return AssetsScene;
    }(cc.Component);
    exports.default = AssetsScene;
    cc._RF.pop();
  }, {
    "../AppConfig": "AppConfig"
  } ],
  SplashScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e5f2fx6EsdKaIwefArW6p9c", "SplashScene");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var AppConfig_1 = require("../AppConfig");
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var SplashScene = function(_super) {
      __extends(SplashScene, _super);
      function SplashScene() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      SplashScene.prototype.getChildNodeByName = function(root, name) {
        if (!root) return null;
        if (root.name === name) return root;
        for (var index = 0; index < root.childrenCount; index++) {
          var element = root.children[index];
          var res = this.getChildNodeByName(element, name);
          if (null !== res) return res;
        }
        return null;
      };
      SplashScene.prototype.start = function() {
        var bg = this.getChildNodeByName(this.node, "bg");
        this.scaleBackgroundBG(bg);
        var icon = this.getChildNodeByName(this.node, "icon");
        icon.opacity = 0;
        cc.tween(icon).to(1, {
          opacity: 255
        }).delay(.8).call(function() {
          2 === AppConfig_1.AppConfig.platform ? cc.director.loadScene("LoginScene", function(err, scene) {
            var container = scene.children[0];
            var script = container.addComponent("LoginScene");
            script.setSceneType("login");
          }) : 1 === AppConfig_1.AppConfig.platform && cc.director.loadScene("AssetsScene");
        }).start();
      };
      SplashScene.prototype.scaleBackgroundBG = function(node) {
        var showAll = Math.min(cc.view.getCanvasSize().width / node.width, cc.view.getCanvasSize().height / node.height);
        var realWidth = node.width * showAll;
        var realHeight = node.height * showAll;
        node.scale = Math.max(cc.view.getCanvasSize().width / realWidth, cc.view.getCanvasSize().height / realHeight);
      };
      SplashScene = __decorate([ ccclass ], SplashScene);
      return SplashScene;
    }(cc.Component);
    exports.default = SplashScene;
    cc._RF.pop();
  }, {
    "../AppConfig": "AppConfig"
  } ]
}, {}, [ "AppConfig", "AssetsScene", "SplashScene" ]);